/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.mycompany.communitylookuptool.Student;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Bryce Ciemiewicz
 */
public class TestStudent {
    
    Student student;
    public TestStudent() {
    }
    
    @BeforeAll
    public static void setUpClass() {       
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
        student = new Student("Bryce", "Ciemiewicz", "Senior", "Berks");
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    void testGetFirstName() {
        assertEquals("Bryce", student.getFirstName());
    }
    
    @Test
    void getLastName() {
        assertEquals("Ciemiewicz", student.getLastName());
    }

    @Test
    void testGetClassYear() {
        assertEquals("Senior", student.getClassYear());
    }

    @Test
    void testGetCampus() {
        assertEquals("Berks", student.getCampus());
    }

    @Test
    void testSetFirstName() {
        student.setFirstName("Rand");
        assertEquals("Rand", student.getFirstName());
    }

    @Test
    void testSetLastName() {
        student.setLastName("Person");
        assertEquals("Person", student.getLastName());
    }

    @Test
    void testSetClassYear() {
        student.setClassYear("Freshman");
        assertEquals("Freshman", student.getClassYear());
    }

    void testSetCampus() {
        student.setCampus("University Park");
        assertEquals("University Park", student.getCampus());
    }

    @Test
    void testToString() {
        assertEquals("Student{firstName=Bryce, lastName=Ciemiewicz, classYear=Senior, campus=Berks}", student.toString());
    }
}
