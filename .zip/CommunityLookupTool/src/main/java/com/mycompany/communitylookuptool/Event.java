/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.communitylookuptool;

import java.util.Date;

/**
 *
 * @author bzc5373
 */
public class Event {
    private String name;
    private String date;
    private String time;
    private String location;
    private String[] people;

    public Event(String name, String date, String time, String location) {
        this.name = name;
        this.date = date;
        this.time = time;
        this.location = location;
        this.people = people;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getLocation() {
        return location;
    }

    public String[] getPeople() {
        return people;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setPeople(String[] people) {
        this.people = people;
    }

    @Override
    public String toString() {
        return "Event{" + "name=" + name + ", date=" + date + ", time=" + time + ", location=" + location + ", people=" + people + '}';
    }  
}